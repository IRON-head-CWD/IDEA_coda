package com.itheima;

import java.util.Scanner;

public class Test01 {
    public static void main(String[] args) {
        //键盘录入
        System.out.println("请输入一个字符串");
        Scanner scanner = new Scanner(System.in);//括号内没有（System.in）
        String str = scanner.next();
        //判断字符串中第一个字符和最后一个字符是否相等
        char first = str.charAt(0);
        char last = str.charAt(str.length() - 1);
        if ("first".equals(last)) {            //first不能与last直接匹配
            //不相等则将字符串反转
            String newString = "";
            char[] chs = new char[str.length() - 1];
            for (int i = 0; i < str.length(); i++) {
                newString += str.charAt(i);
            }
            str = newString;
            //将字符串中字符存入字符数组
            for (int i = 0; i < str.length(); i++) {
                chs[i] = str.charAt(i);//缺少变量
            }
        }
        //将数组中下标是奇数的字符用“*”号替代；
        char[] chs = new char[str.length() - 1];
        for (int i = 0; i < chs.length; i++) {
            if (i % 2 != 0) {
                chs[].remove(i--);            //替代
            }
        }//遍历数组
        for (int i = 0; i < chs.length; i++) {
            System.out.println(chs[i]);
        }
    }
}
